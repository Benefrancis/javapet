create trigger TG_SQ_ANIMAIS
    before insert or update
    on TB_ANIMAL
    for each row
begin
    if inserting and :new.ID_ANIMAL is null then
        :new.ID_ANIMAL := SQ_ANIMAIS.nextval;
    end if;
end;
/

