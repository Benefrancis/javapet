create trigger TG_SQ_SERVICOS
    before insert or update
    on TB_SERVICO
    for each row
begin
    if inserting and :new.ID_SERVICO is null or :new.ID_SERVICO < 1 then
        :new.ID_SERVICO := SQ_SERVICOS.nextval;
    end if;
end;
/

