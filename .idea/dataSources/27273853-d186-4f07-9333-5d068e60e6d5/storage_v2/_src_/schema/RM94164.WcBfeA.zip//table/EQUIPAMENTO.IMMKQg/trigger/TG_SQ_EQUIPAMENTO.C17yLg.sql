create trigger TG_SQ_EQUIPAMENTO
    before insert or update
    on EQUIPAMENTO
    for each row
begin
    if inserting and :new.ID_EQUIPAMENTO is null then
        :new.ID_EQUIPAMENTO := SQ_EQUIPAMENTO.nextval;
    end if;
end;
/

