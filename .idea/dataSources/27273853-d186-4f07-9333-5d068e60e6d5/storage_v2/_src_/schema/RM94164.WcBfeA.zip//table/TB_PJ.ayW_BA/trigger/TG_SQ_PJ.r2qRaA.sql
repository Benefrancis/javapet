create trigger TG_SQ_PJ
    before insert or update
    on TB_PJ
    for each row
begin
    if inserting and :new.ID_PESSOA is null then
        :new.ID_PESSOA := SQ_PESSOAS.nextval;
    end if;
end;
/

